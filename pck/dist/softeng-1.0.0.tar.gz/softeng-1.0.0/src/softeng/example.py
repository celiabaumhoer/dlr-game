def print_world():
    print('hello world')

# print hello world
print_world()